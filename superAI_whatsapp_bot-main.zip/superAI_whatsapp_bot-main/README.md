# superAI_whatsapp_bot
<h3><b>Join telegram</b> : https://t.me/ifeelmohiit <br></h3>
<br>
This is a source code to build a WhatsApp bot using OpenAI bot and Node.js. The bot is capable of understanding natural language and providing information on various topics. It can be used to answer questions, provide advice, and even have conversations with users. With this source code, you can create a powerful bot that can be used for a variety of purposes. <br>

NOTE: DON'T MESS UP WITH INDEX.JS FILE. <br>

# How to Install? 
$ git clone https://github.com/ifeelmohiit/superAI_whatsapp_bot.git <br>
$ cd superAI_whatsapp_bot <br>
$ npm install <br>
$ ls <br>
$ nano accesser.json <br> 
$ paste the api in the given place then { press ctrl + o then enter } and then { press ctrl + x} <br>
$ ls<br>
$ node index.js <br><br>

<br> 



<h1>NOTE:- AFTER SCANING THE QR CODE  RESTART YOUR TERMINAL </h1>
<h4> BHAIYO MAINE ACHE SE EXPLAIN KR DIYA HAI KAISE KYA KARNA HAI <br> AGAR FIR V PROBLEM HUI TO CONTACT ON MY SOCIAL HANDLE  </h4>
      


<b>Visit: on instagram if you have any problem :- 
<a href="https://www.instagram.com/ifeelmohiit/">instagram</a> <br><b>

# How to get OpenAI API?
Visit: https://beta.openai.com/account/api-keys
